package re222gr_assign2.Ex02;

public class Passenger {

	/* class that defines the methods and values for the passenger class */

    private final int costPassenger = 20;
    public int costPassenger() {
    	return this.costPassenger;
    }


}