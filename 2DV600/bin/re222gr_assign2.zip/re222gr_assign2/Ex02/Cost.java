/**
 * 
 */
package re222gr_assign2.Ex02;

/**
 * @author rjosi
 *
 */
public class Cost extends Passenger {
    private final int cost = 0;
    public int costPassenger() {
    	return this.cost;
    }
}
